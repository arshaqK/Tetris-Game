/* PROGRAMMING FUNDAMENTAL'S PROJECT FOR FALL 2022 BS(CS)
 * Shape of each piece is represented by rows in the array.
 * TIP: Name the array what is already been coded to avoid any unwanted errors.
 */
 
// Syed Arshaq Hussain Kirmani		22i-0834 	Final Project

 
 int BLOCKS[7][4]={{0,2,4,5},{0,1,2,3},{0,2,3,4},{0,2,4,6},{0,2,3,5},{1,3,2,4},{1,3,5,4}}; // L, O, T, I, S, Z, J
